#ifndef CONFIG_H
#define CONFIG_H

#define FOO

#endif
