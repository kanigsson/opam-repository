open! Import
include Lazy

let of_thunk = from_fun
