include Base.Container

module type S1_permissions = Container_intf.S1_permissions
