open! Import

include Optional_syntax_intf (** @inline *)
