include Base.Blit
include Blit_intf
