open! Core_kernel

include Expect_test_helpers_kernel

let () = Sexp.of_int_style := `Underscores
