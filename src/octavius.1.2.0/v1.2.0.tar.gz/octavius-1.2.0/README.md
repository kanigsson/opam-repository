Octavius — ocamldoc comment syntax parser
-----------------------------------------
v1.2.0

Octavius is a library to parse the `ocamldoc` comment syntax.

## Installation

Octavius can be installed with `opam`:

    opam install octavius

If you don't use `opam` consult the [`opam`](opam) file for build instructions.


