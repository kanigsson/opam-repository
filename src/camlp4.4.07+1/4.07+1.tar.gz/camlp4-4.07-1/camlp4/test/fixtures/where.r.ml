x where x = 42;
