## v0.10

- Enabled `-safe-string`.

- Added functions `Out_channel.output_bytes`, `Out_channel.output_substring`.

- Added functions `In_channel.equal` and `Out_channel.equal`, implemented as `phys_equal`.

## v0.9

Initial release.
