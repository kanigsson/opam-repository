## 109.10.00

- Improved error messages in presence of GADTs.

