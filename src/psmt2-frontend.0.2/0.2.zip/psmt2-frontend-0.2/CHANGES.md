second public release 0.2, January 18, 2019
================================

- Add some small examples and a standalone binary for parsing and typing smt2 language.
- Improve ReadMe
- Add more options for logic and verbose
- Correct bug in lexing for hexadecimal and binary number
- Add support for "_" in pattern matching in parsing/syntax
- Correct typing for DataTypes
- Improve typing of logic for futur support of BV and FP
- Add option for keeping location in parsed tree

first public release 0.1, April 20, 2018
================================

- First release


